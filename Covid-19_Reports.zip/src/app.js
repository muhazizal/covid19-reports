import 'bootstrap';
import './styles/style.css';
import main from './scripts/view/main.js';

document.addEventListener('DOMContentLoaded', main);